"""
Minimal example showing how to plug Evaluator into an Inspect AI evaluation flow.
This is intentionally small: you would normally register scoring functions in an Inspect EvaluationSpec.
"""
from .metrics import Evaluator

def run_inspect_example(sources, references, candidates):
    evaluator = Evaluator(batch_size=8)
    results = evaluator.evaluate_all(sources, references, candidates)
    # Convert `results` into Inspect evaluation items or attach to your inspect run as required.
    return results
