"""
Metric wrappers for translation evaluation.
Computes BLEU, BERTScore, TER, NIST, METEOR, COMET and a combined final_score.
"""
from typing import List, Dict, Any
import math

class Evaluator:
    def __init__(self, batch_size: int = 16):
        self.batch_size = batch_size
        self._bertscorer = None
        self._comet = None

    def _import_sacrebleu(self):
        try:
            import sacrebleu
            return sacrebleu
        except Exception as e:
            raise ImportError("sacrebleu is required. pip install sacrebleu") from e

    def _import_nltk(self):
        try:
            import nltk
            return nltk
        except Exception as e:
            raise ImportError("nltk is required. pip install nltk") from e

    def _import_bertscore(self):
        if self._bertscorer is None:
            try:
                from bert_score import BERTScorer
                self._bertscorer = BERTScorer(lang="en", rescale_with_baseline=True)
            except Exception as e:
                raise ImportError("bert-score is required. pip install bert-score") from e
        return self._bertscorer

    def _import_evaluate_comet(self):
        if self._comet is None:
            try:
                import evaluate
                self._comet = evaluate.load('comet')
            except Exception as e:
                raise ImportError("evaluate and comet are required. pip install evaluate unbabel-comet") from e
        return self._comet

    def compute_bleu(self, references: List[str], candidates: List[str]) -> List[float]:
        sacrebleu = self._import_sacrebleu()
        scores = []
        for ref, cand in zip(references, candidates):
            try:
                sc = sacrebleu.sentence_bleu(cand, [ref]).score  # 0..100
            except Exception:
                sc = float(sacrebleu.corpus_bleu([cand], [[ref]]).score)
            scores.append(sc / 100.0)  # normalize to 0..1
        return scores

    def compute_ter(self, references: List[str], candidates: List[str]) -> List[float]:
        sacrebleu = self._import_sacrebleu()
        scores = []
        for ref, cand in zip(references, candidates):
            try:
                ter = sacrebleu.metrics.ter.ter(cand, ref)
            except Exception:
                ter = sacrebleu.corpus_ter([cand], [[ref]])
            # normalize to 0..1 if returned as percent
            if ter > 1.5:
                ter = ter / 100.0
            scores.append(min(max(float(ter), 0.0), 1.0))
        return scores

    def compute_nist(self, references: List[str], candidates: List[str]) -> List[float]:
        nltk = self._import_nltk()
        try:
            nltk.data.find('tokenizers/punkt')
        except Exception:
            nltk.download('punkt')
        from nltk.translate import nist_score
        scores = []
        for ref, cand in zip(references, candidates):
            try:
                s = nist_score.sentence_nist([ref.split()], cand.split(), n=5)
            except Exception:
                s = 0.0
            scores.append(float(s))
        return scores

    def compute_meteor(self, references: List[str], candidates: List[str]) -> List[float]:
        nltk = self._import_nltk()
        try:
            nltk.data.find('tokenizers/punkt')
        except Exception:
            nltk.download('punkt')
        from nltk.translate import meteor_score
        scores = []
        for ref, cand in zip(references, candidates):
            try:
                s = meteor_score.meteor_score([ref], cand)
            except Exception:
                s = 0.0
            scores.append(float(s))
        return scores

    def compute_bertscore(self, references: List[str], candidates: List[str]) -> List[float]:
        scorer = self._import_bertscore()
        P, R, F1 = scorer.score(candidates, references, batch_size=self.batch_size)
        return [float(f) for f in F1]

    def compute_comet(self, sources: List[str], references: List[str], candidates: List[str]) -> List[float]:
        metric = self._import_evaluate_comet()
        try:
            out = metric.compute(predictions=candidates, references=references, sources=sources, batch_size=self.batch_size)
            if isinstance(out, dict) and 'scores' in out:
                scores = out['scores']
            elif isinstance(out, float):
                scores = [float(out)] * len(candidates)
            elif isinstance(out, dict) and 'score' in out:
                scores = [float(out['score'])] * len(candidates)
            else:
                val = list(out.values())[0]
                scores = [float(val)] * len(candidates)
        except Exception as e:
            raise RuntimeError("COMET evaluation failed. Ensure models are available and evaluate/unbabel-comet is installed") from e
        return scores

    def _minmax_normalize(self, arr: List[float], invert: bool = False) -> List[float]:
        if not arr:
            return arr
        mn = min(arr)
        mx = max(arr)
        if abs(mx - mn) < 1e-12:
            return [1.0 for _ in arr]
        norm = [ (x - mn) / (mx - mn) for x in arr ]
        if invert:
            norm = [1.0 - v for v in norm]
        return norm

    def evaluate_all(self, sources: List[str], references: List[str], candidates: List[str]) -> Dict[str, Any]:
        assert len(sources) == len(references) == len(candidates), "All inputs must be same length"
        n = len(sources)
        results = { 'per_sentence': [] }

        # compute metrics (per-sentence)
        bleu = self.compute_bleu(references, candidates)          # 0..1
        ter = self.compute_ter(references, candidates)            # 0..1 (lower better)
        nist = self.compute_nist(references, candidates)          # raw (will normalize)
        meteor = self.compute_meteor(references, candidates)      # 0..1
        bert = self.compute_bertscore(references, candidates)     # 0..1 (F1)
        try:
            comet = self.compute_comet(sources, references, candidates)
        except Exception:
            comet = [0.0]*n

        # Normalize metrics to 0..1 and invert TER
        bleu_n = self._minmax_normalize(bleu)
        ter_n = self._minmax_normalize(ter, invert=True)
        nist_n = self._minmax_normalize(nist)
        meteor_n = self._minmax_normalize(meteor)
        bert_n = self._minmax_normalize(bert)
        comet_n = self._minmax_normalize(comet)

        final_scores = []
        for i in range(n):
            parts = [bleu_n[i], ter_n[i], nist_n[i], meteor_n[i], bert_n[i], comet_n[i]]
            final = sum(parts) / len(parts)
            final_scores.append(final)
            results['per_sentence'].append({
                'source': sources[i],
                'reference': references[i],
                'candidate': candidates[i],
                'bleu': bleu[i],
                'ter': ter[i],
                'nist': nist[i],
                'meteor': meteor[i],
                'bertscore_f1': bert[i],
                'comet': comet[i],
                'normalized': {
                    'bleu': bleu_n[i],
                    'ter': ter_n[i],
                    'nist': nist_n[i],
                    'meteor': meteor_n[i],
                    'bertscore_f1': bert_n[i],
                    'comet': comet_n[i],
                },
                'final_score': final
            })

        results['aggregate'] = {
            'bleu_mean': sum(bleu)/n,
            'ter_mean': sum(ter)/n,
            'nist_mean': sum(nist)/n,
            'meteor_mean': sum(meteor)/n,
            'bertscore_f1_mean': sum(bert)/n,
            'comet_mean': sum(comet)/n,
            'final_mean': sum(final_scores)/n
        }
        return results
