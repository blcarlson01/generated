#!/usr/bin/env python3
"""CLI wrapper to run the evaluation on a CSV file."""
import argparse
import json
import pandas as pd
from evaluate_translations.metrics import Evaluator

def main():
    parser = argparse.ArgumentParser(description='Evaluate translations with multiple metrics.')
    parser.add_argument('--input', required=True, help='CSV input with columns: source,reference,candidate')
    parser.add_argument('--out', default='results.json', help='Output JSON file with scores')
    parser.add_argument('--batch-size', type=int, default=16, help='Batch size for heavy metrics')
    args = parser.parse_args()

    df = pd.read_csv(args.input)
    sources = df['source'].astype(str).tolist()
    references = df['reference'].astype(str).tolist()
    candidates = df['candidate'].astype(str).tolist()

    evaluator = Evaluator(batch_size=args.batch_size)
    results = evaluator.evaluate_all(sources, references, candidates)

    with open(args.out, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print(f"Wrote results to {args.out}")

if __name__ == '__main__':
    main()
