import os
import json
import csv
import openai

# Load system prompt
with open("system_prompt.txt") as f:
    system_prompt = f.read()

# Output files
csv_out = "dashboard_output.csv"
html_out = "dashboard.html"
email_out = "email_summary.txt"

fields = ["Conversation", "Concern Score", "Categories", "Snippets", "Suggested Action"]
rows = []

# Analyze each conversation
for fname in os.listdir("conversations"):
    if fname.endswith(".json"):
        with open(os.path.join("conversations", fname)) as f:
            convo = json.load(f)

        messages = [{"role": "system", "content": system_prompt}] + convo

        try:
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=messages,
                temperature=0.2
            )
            output = response['choices'][0]['message']['content']

            import re
            score = re.search(r'Concern Score[: ]+(\d)', output)
            cats = re.search(r'Categories Detected[: ]+(.+)', output)
            quotes = re.search(r'Key Evidence Snippets[: ]+(.+)', output)
            action = re.search(r'Suggested Action[: ]+(.+)', output)

            row = [
                fname,
                score.group(1) if score else "",
                cats.group(1).strip() if cats else "",
                quotes.group(1).strip() if quotes else "",
                action.group(1).strip() if action else ""
            ]
            rows.append(row)
        except Exception as e:
            rows.append([fname, "ERROR", str(e), "", ""])

# Write CSV
with open(csv_out, "w", newline='') as f:
    writer = csv.writer(f)
    writer.writerow(fields)
    writer.writerows(rows)

# Write static HTML dashboard
with open(html_out, "w") as f:
    f.write('<html><head><title>LLM Risk Dashboard</title></head><body>')
    f.write('<h1>User Conversation Risk Overview</h1><table border="1"><tr>')
    for h in fields:
        f.write(f"<th>{h}</th>")
    f.write("</tr>")
    for row in rows:
        f.write("<tr>" + "".join(f"<td>{col}</td>" for col in row) + "</tr>")
    f.write("</table></body></html>")

# Generate plain-text summary for email
with open(email_out, "w") as f:
    high_risk = [r for r in rows if r[1] == '3']
    f.write("LLM Mental Health Moderation Summary
")
    f.write(f"Total Conversations: {len(rows)}
")
    f.write(f"High Risk Cases: {len(high_risk)}

")
    for r in high_risk:
        f.write(f"🔴 {r[0]}: {r[2]} — {r[4]}
")
