# LLM Mental Health Dashboard + Email Summary

This toolkit helps analyze multiple user-LLM conversations for signs of:
- Mental health concerns (loneliness, anxiety, suicidal ideation)
- Over-attachment or romantic fixation on the LLM

## Features
- ✅ Batch processing of `.json` conversations
- ✅ Generates:
  - `dashboard_output.csv`: for Excel/Sheets
  - `dashboard.html`: static web report
  - `email_summary.txt`: plaintext moderation summary

## Usage

1. Install OpenAI Python SDK:
```
pip install openai
```

2. Set your API key:
```
export OPENAI_API_KEY=your_key_here
```

3. Run the batch analyzer:
```
python batch_analyze.py
```

## Output Overview
- Use `dashboard.html` to quickly scan risk cases
- Use `email_summary.txt` to send triage notes to moderators

⚠️ This tool is **not a diagnostic system**. Use for triage/moderation only.
