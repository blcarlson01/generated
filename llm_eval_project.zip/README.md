# LLM Evaluation with Inspect AI

This project evaluates LLM outputs against gold reference answers using:
- Embedding similarity (OpenAI text-embedding-3-large)
- BERTScore
- LLM-as-a-judge (GPT-4o)
- Weighted composite scoring

## Setup

```bash
pip install -r requirements.txt
export OPENAI_API_KEY="your_api_key_here"
```

## Run Evaluation

```bash
inspect eval tasks/open_ended_eval.py --model openai/gpt-4o
inspect eval tasks/open_ended_eval.py --model openai/gpt-4o-mini
inspect eval tasks/open_ended_eval.py --model openai/gpt-3.5-turbo
```

## View Results

Inspect saves results as JSONL by default.  
You can load them into a dataframe or view with the Inspect UI:

```bash
inspect view path/to/results.jsonl
```
