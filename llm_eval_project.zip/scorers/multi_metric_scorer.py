import numpy as np
from bert_score import score as bert_score
from inspect_ai.scorer import Scorer
from openai import OpenAI

class MultiMetricScorer(Scorer):
    def __init__(self, embedding_model="text-embedding-3-large", judge_model="gpt-4o", weights=None):
        super().__init__()
        self.client = OpenAI()
        self.embedding_model = embedding_model
        self.judge_model = judge_model
        self.weights = weights or {"embed": 0.4, "bertscore": 0.2, "judge": 0.4}

    def embedding_similarity(self, ref, hyp):
        res = self.client.embeddings.create(input=[ref, hyp], model=self.embedding_model)
        v1, v2 = np.array(res.data[0].embedding), np.array(res.data[1].embedding)
        return float(np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2)))

    def bert_score(self, refs, hyps):
        P, R, F1 = bert_score(hyps, refs, lang="en", rescale_with_baseline=True)
        return float(F1.mean())

    def judge_score(self, ref, hyp):
        prompt = f"""
        Reference Answer:
        {ref}

        Model Answer:
        {hyp}

        Score the model answer from 0 to 10 for:
        - Accuracy (factual match to the reference)
        - Completeness (covers all key points)

        Respond with only the numeric score.
        """
        resp = self.client.chat.completions.create(
            model=self.judge_model,
            messages=[{"role": "user", "content": prompt}]
        )
        try:
            return float(resp.choices[0].message.content.strip())
        except:
            return 0.0

    def score_sample(self, sample, prediction: str):
        ref = sample.target
        sim = self.embedding_similarity(ref, prediction)
        bs = self.bert_score([ref], [prediction])
        mg = self.judge_score(ref, prediction)
        composite = self.weights["embed"] * sim + self.weights["bertscore"] * bs + self.weights["judge"] * (mg / 10)

        return {
            "score": composite,
            "embedding_similarity": sim,
            "bert_score": bs,
            "judge_score": mg
        }
