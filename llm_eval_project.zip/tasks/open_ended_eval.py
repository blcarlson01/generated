from inspect_ai import Task, task
from inspect_ai.dataset import Dataset
from inspect_ai.solver import generate
from scorers.multi_metric_scorer import MultiMetricScorer

@task
def open_ended_eval():
    dataset = Dataset.from_jsonl("data/sample_dataset.jsonl")
    return Task(
        dataset=dataset,
        plan=[generate()],
        scorer=MultiMetricScorer()
    )
