# LLM Refusal Detector

This tool detects refusals in language model responses and generates a static dashboard for review.

## How to Use

1. Install dependencies:
   ```
   pip install openai jinja2
   ```

2. Set your OpenAI API key:
   ```
   export OPENAI_API_KEY=sk-...
   ```

3. Add your assistant responses to `data/conversations.json`.

4. Run the script:
   ```
   python analyze_refusals.py
   ```

5. Open `output/dashboard.html` to view results.
