import json
from pathlib import Path
from openai import OpenAI
from jinja2 import Template

# Load input data
with open("data/conversations.json", "r") as f:
    assistant_responses = json.load(f)

# Load prompt
with open("system_prompt.txt", "r") as f:
    base_prompt = f.read()

client = OpenAI()  # Ensure API key is configured via env var or config

results = []

for i, response in enumerate(assistant_responses):
    print(f"Analyzing response {i+1}/{len(assistant_responses)}...")
    completion = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": base_prompt},
            {"role": "user", "content": response}
        ]
    )
    output = completion.choices[0].message.content
    results.append({
        "id": i + 1,
        "response": response,
        "analysis": output
    })

# Save results
Path("output").mkdir(exist_ok=True)
with open("output/results.json", "w") as f:
    json.dump(results, f, indent=2)

# Generate dashboard
with open("output/dashboard.html", "w") as f:
    f.write(Template("""
    <html>
    <head>
      <title>LLM Refusal Analysis Dashboard</title>
      <style>
        body { font-family: sans-serif; margin: 2em; }
        .entry { margin-bottom: 2em; border-bottom: 1px solid #ccc; padding-bottom: 1em; }
        .refusal { color: red; font-weight: bold; }
        .no-refusal { color: green; font-weight: bold; }
        pre { background: #f6f6f6; padding: 1em; }
      </style>
    </head>
    <body>
      <h1>LLM Refusal Detection Results</h1>
      {% for r in results %}
        <div class="entry">
          <h2>Response {{ r.id }}</h2>
          <p><strong>Refusal Status:</strong> 
            {% if "Refusal Detected: Yes" in r.analysis %}
              <span class="refusal">Refusal Detected</span>
            {% else %}
              <span class="no-refusal">No Refusal</span>
            {% endif %}
          </p>
          <h3>Assistant Response:</h3>
          <pre>{{ r.response }}</pre>
          <h3>Analysis:</h3>
          <pre>{{ r.analysis }}</pre>
        </div>
      {% endfor %}
    </body>
    </html>
    """).render(results=results))

print("Analysis complete. See output/dashboard.html")
