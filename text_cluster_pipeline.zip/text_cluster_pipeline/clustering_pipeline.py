import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import cosine_distances
import openai
import umap
import logging

'''
import joblib
from sklearn.cluster import KMeans
kmeans = KMeans(n_clusters=3, random_state=42)
filename = 'kmeans_model.joblib'
joblib.dump(kmeans, filename)
filename = 'kmeans_model.joblib'
loaded_kmeans_model = joblib.load(filename)

import logging
import joblib
from sklearn.cluster import KMeans
import os

K_CLUSTERS = 3  # Example value

def cluster_embeddings(embeddings, k=K_CLUSTERS, model_path='kmeans_model.joblib'):
    """
    Clusters embeddings using KMeans and either loads a pre-trained model or trains a new one.

    Args:
        embeddings: The data (embeddings) to cluster.
        k: The number of clusters (K). Defaults to K_CLUSTERS.
        model_path: The path to save/load the KMeans model. Defaults to 'kmeans_model.joblib'.

    Returns:
        A tuple containing:
            - kmeans: The fitted KMeans model.
            - centroids: The cluster centroids.
            - labels: The cluster labels for each embedding.
    """

    if os.path.exists(model_path):
        logging.info(f"Loading pre-trained KMeans model from {model_path}")
        try:
            kmeans = joblib.load(model_path)
            # Ensure the loaded model has the correct number of clusters
            if kmeans.n_clusters != k:
                logging.warning(f"Loaded model has {kmeans.n_clusters} clusters, expected {k}. Retraining.")
                kmeans = KMeans(n_clusters=k, random_state=42)
                kmeans.fit(embeddings)
                joblib.dump(kmeans, model_path)  # Save the newly trained model
                logging.info(f"Retrained and saved KMeans model to {model_path}.")
        except Exception as e:  # Catch potential errors during loading, e.g., file corruption
            logging.error(f"Error loading model from {model_path}: {e}. Retraining KMeans.")
            kmeans = KMeans(n_clusters=k, random_state=42)
            kmeans.fit(embeddings)
            joblib.dump(kmeans, model_path)
            logging.info(f"Retrained and saved KMeans model to {model_path}.")
    else:
        logging.info(f"No pre-trained model found at {model_path}. Training a new KMeans model.")
        kmeans = KMeans(n_clusters=k, random_state=42)
        kmeans.fit(embeddings)
        joblib.dump(kmeans, model_path)  # Save the newly trained model
        logging.info(f"Saved KMeans model to {model_path}.")

    # --- THIS IS THE KEY CHANGE ---
    labels = kmeans.predict(embeddings)
    # ------------------------------

    centroids = kmeans.cluster_centers_
    logging.info(f"Clustered {len(embeddings)} points into {k} clusters.")
    return kmeans, centroids, labels

'''


openai.api_key = os.getenv("OPENAI_API_KEY")
EMBEDDING_MODEL = "text-embedding-3-small"
EMBED_DIM = 1536
K_CLUSTERS = 5

logging.basicConfig(
    filename="clustering_log.txt",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def get_openai_embeddings(texts, model=EMBEDDING_MODEL):
    embeddings = []
    for text in texts:
        try:
            response = openai.embeddings.create(input=[text], model=model)
            embedding = response.data[0].embedding
            embeddings.append(embedding)
        except Exception as e:
            logging.error(f"Embedding failed for: {text[:30]}... | Error: {e}")
            embeddings.append(np.zeros(EMBED_DIM))
    return np.array(embeddings)

def cluster_embeddings(embeddings, k=K_CLUSTERS):
    kmeans = KMeans(n_clusters=k, random_state=42)
    labels = kmeans.fit_predict(embeddings)
    centroids = kmeans.cluster_centers_
    logging.info(f"Clustered {len(embeddings)} points into {k} clusters.")
    return kmeans, centroids, labels

def classify_new_data(new_embeddings, centroids, z_threshold=2.5):
    distances = cosine_distances(new_embeddings, centroids)
    closest_cluster = np.argmin(distances, axis=1)
    closest_distance = np.min(distances, axis=1)

    outliers = []
    for i, dist in enumerate(closest_distance):
        cluster_idx = closest_cluster[i]
        cluster_distances = distances[:, cluster_idx]
        mean = np.mean(cluster_distances)
        std = np.std(cluster_distances)
        is_outlier = dist > mean + z_threshold * std
        outliers.append(is_outlier)

    logging.info(f"Classified {len(new_embeddings)} new points. Outliers: {sum(outliers)}")
    return closest_cluster, closest_distance, outliers

def visualize_with_umap(embeddings, labels, title="UMAP Projection of Clusters"):
    reducer = umap.UMAP(n_neighbors=15, min_dist=0.1, metric='cosine', random_state=42)
    reduced = reducer.fit_transform(embeddings)

    plt.figure(figsize=(10, 6))
    scatter = plt.scatter(reduced[:, 0], reduced[:, 1], c=labels, cmap='tab10', s=50)
    plt.title(title)
    plt.xlabel("UMAP 1")
    plt.ylabel("UMAP 2")
    plt.colorbar(scatter, label="Cluster ID")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("umap_clusters.png")
    plt.show()

if __name__ == "__main__":
    seed_texts = [
        "CPU usage exceeded threshold on server.",
        "Suspicious login detected in system logs.",
        "Q3 revenue exceeds forecasts by 20 percent.",
        "Firewall blocked unauthorized access attempt.",
        "Customer NPS score increased last month."
    ]
    logging.info("Embedding seed texts...")
    seed_embeddings = get_openai_embeddings(seed_texts)

    logging.info("Clustering seed embeddings...")
    kmeans_model, centroids, cluster_labels = cluster_embeddings(seed_embeddings)

    new_texts = [
        "Alert: database server memory usage high.",
        "Marketing team launching new campaign.",
        "Unauthorized device connected to network.",
        "CEO preparing for annual earnings call."
    ]
    logging.info("Embedding new incoming texts...")
    new_embeddings = get_openai_embeddings(new_texts)

    logging.info("Classifying new data points...")
    cluster_ids, distances, outliers = classify_new_data(new_embeddings, centroids)

    df_results = pd.DataFrame({
        "text": new_texts,
        "assigned_cluster": cluster_ids,
        "distance_to_centroid": distances,
        "is_outlier": outliers
    })

    print("\nClassification Results:")
    print(df_results)

    all_embeddings = np.vstack([seed_embeddings, new_embeddings])
    all_labels = np.concatenate([cluster_labels, [-1 if o else cid for cid, o in zip(cluster_ids, outliers)]])
    visualize_with_umap(all_embeddings, all_labels, title="UMAP of Seed + New Points")
